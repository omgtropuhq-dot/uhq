package models

import "time"

type ScrapingResult struct {
	Url           string                 `json:"url"`
	Path          string                 `json:"path"`
	DiscoveredAt  time.Time              `json:"discoveredAt"`
	Services      []string               `json:"services"`
	Credentials   map[string]interface{} `json:"credentials"`
	Status        string                 `json:"status"`
	ValidationMsg string                 `json:"validationMsg"`
	IsNew         bool                   `json:"isNew"`

	// Secrets — exclus du JSON (stockés en mémoire uniquement)
	AKIA             string `json:"-"`
	SecretKey        string `json:"-"`
	Region           string `json:"-"`
	SendGridApiKey   string `json:"-"`
	BrevoApiKey      string `json:"-"`
	StripeSecretKey  string `json:"-"`
	TwilioAccountSid string `json:"-"`
	TwilioAuthToken  string `json:"-"`
	MailgunApiKey    string `json:"-"`
	NewMailgunApiKey string `json:"-"`
	PostmarkApiKey   string `json:"-"`
	SmtpHost         string `json:"-"`
	SmtpUser         string `json:"-"`
	SmtpPass         string `json:"-"`
	SmtpFrom         string `json:"-"`
	SparkpostApiKey  string `json:"-"`
	MandrillApiKey   string `json:"-"`
	MailersendApiKey string `json:"-"`
	XsmtpsibApiKey   string `json:"-"`

	// AWS
	AwsStatus      string `json:"aws_status,omitempty"`
	AwsPermissions string `json:"aws_permissions,omitempty"`
	AwsSesQuota    string `json:"aws_ses_quota,omitempty"`
	AwsSnsLimit    string `json:"aws_sns_limit,omitempty"`

	// Brevo / XSMTP
	BrevoEmailCredits int    `json:"brevo_email_credits,omitempty"`
	BrevoSmsCredits   int    `json:"brevo_sms_credits,omitempty"`
	BrevoSender       string `json:"brevo_sender,omitempty"`

	// Stripe
	StripeBalance      string `json:"stripe_balance,omitempty"`
	StripeBusinessName string `json:"stripe_business_name,omitempty"`

	// Twilio
	TwilioBalance      string `json:"twilio_balance,omitempty"`
	TwilioNumbersCount int    `json:"twilio_numbers_count,omitempty"`

	// SendGrid
	SendGridStatus string `json:"sendgrid_status,omitempty"`
	SendGridQuota  string `json:"sendgrid_quota,omitempty"`
	SendGridUsed   int    `json:"sendgrid_used,omitempty"`
	SendGridEmail  string `json:"sendgrid_email,omitempty"`
}

func (r *ScrapingResult) HasCredentials() bool {
	return r.AKIA != "" ||
		r.SendGridApiKey != "" ||
		r.BrevoApiKey != "" ||
		r.StripeSecretKey != "" ||
		r.TwilioAccountSid != "" ||
		r.MailgunApiKey != "" ||
		r.NewMailgunApiKey != "" ||
		r.PostmarkApiKey != "" ||
		r.SmtpHost != "" ||
		r.MandrillApiKey != "" ||
		r.MailersendApiKey != "" ||
		r.XsmtpsibApiKey != ""
}
