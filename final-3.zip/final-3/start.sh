#!/bin/bash
# GlitchCracker — Linux 1Gbps optimisé

echo "[*] Application des optimisations kernel..."

# Limites fichiers/processus
ulimit -n 1000000
ulimit -u 1000000

# Buffers réseau TCP
sysctl -w net.core.rmem_max=268435456
sysctl -w net.core.wmem_max=268435456
sysctl -w net.ipv4.tcp_rmem="4096 87380 268435456"
sysctl -w net.ipv4.tcp_wmem="4096 65536 268435456"
sysctl -w net.core.netdev_max_backlog=250000

# Connexions simultanées
sysctl -w net.core.somaxconn=65535
sysctl -w net.ipv4.ip_local_port_range="1024 65535"
sysctl -w net.ipv4.tcp_max_syn_backlog=65535

# Réutilisation ports TIME_WAIT — critique pour haute vitesse
sysctl -w net.ipv4.tcp_tw_reuse=1
sysctl -w net.ipv4.tcp_fin_timeout=10
sysctl -w net.ipv4.tcp_keepalive_time=60
sysctl -w net.ipv4.tcp_keepalive_intvl=10
sysctl -w net.ipv4.tcp_keepalive_probes=3
sysctl -w net.ipv4.tcp_max_orphans=131072

# Performance réseau
sysctl -w net.ipv4.tcp_fastopen=3
sysctl -w net.ipv4.tcp_slow_start_after_idle=0

# conntrack — augmenter si nécessaire
sysctl -w net.netfilter.nf_conntrack_max=1000000 2>/dev/null || true
sysctl -w net.nf_conntrack_max=1000000 2>/dev/null || true

echo "[+] Optimisations appliquées"
echo "[*] Lancement GlitchCracker..."
echo ""

# GOGC=200 — GC moins fréquent, meilleur débit réseau
GOGC=200 GOMAXPROCS=$(nproc) ./glitchcracker
