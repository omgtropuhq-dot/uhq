#!/bin/bash
echo "[*] Compilation GlitchCracker..."
export CGO_ENABLED=0
export GOOS=linux
export GOARCH=amd64
go build -ldflags="-s -w" -o glitchcracker .
if [ $? -eq 0 ]; then
    echo "[+] Compilation OK → ./glitchcracker"
    echo "[*] Lance avec: sudo ./start.sh"
else
    echo "[!] Erreur de compilation"
    exit 1
fi
