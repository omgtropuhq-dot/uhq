package scanner

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"hash/fnv"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"glitchcracker/internal/detector"
	"glitchcracker/pkg/models"
)

// ─────────────────────────────────────────────
// Constantes
// ─────────────────────────────────────────────
const (
	resultsChanSize = 500_000
	bodyLimit       = 512 * 1024
	taskChanSize    = 5_000_000
	numShards       = 512 // shards pour visited — réduit contention de 512x vs sync.Map
	numFileReaders  = 8   // readers parallèles par fichier
)

// ─────────────────────────────────────────────
// ShardedSet — remplace sync.Map pour visited
// sync.Map est conçu pour append-only léger.
// Avec 3000+ workers en écriture simultanée,
// un ShardedSet avec N shards réduit la contention
// de N fois en distribuant les locks.
// ─────────────────────────────────────────────
type shardEntry struct {
	mu sync.Mutex
	m  map[uint64]struct{} // hash de l'URL au lieu de la string — moins de RAM
}

type ShardedSet struct {
	shards [numShards]shardEntry
}

func newShardedSet() *ShardedSet {
	s := &ShardedSet{}
	for i := range s.shards {
		s.shards[i].m = make(map[uint64]struct{}, 4096)
	}
	return s
}

func (s *ShardedSet) setIfAbsent(key string) bool {
	// Hash FNV-64 — rapide, distribution uniforme
	h := fnv.New64a()
	h.Write([]byte(key))
	hash := h.Sum64()
	shardIdx := hash % numShards

	sh := &s.shards[shardIdx]
	sh.mu.Lock()
	_, exists := sh.m[hash]
	if !exists {
		sh.m[hash] = struct{}{}
	}
	sh.mu.Unlock()
	return !exists
}

// ─────────────────────────────────────────────
// Buffer pool — zéro allocation en hot path
// ─────────────────────────────────────────────
var bufPool = sync.Pool{
	New: func() interface{} {
		buf := make([]byte, bodyLimit)
		return &buf
	},
}

// ─────────────────────────────────────────────
// Engine
// ─────────────────────────────────────────────
type Engine struct {
	Client      *http.Client
	Workers     int
	ExtraPaths  []string
	ResultsChan chan models.ScrapingResult

	TotalURLs atomic.Int64
	Total     atomic.Int64
	Processed atomic.Int64
	TotalHits atomic.Int64

	taskChan chan string
	visited  *ShardedSet
	wg       sync.WaitGroup
	cancel   context.CancelFunc
}

// ─────────────────────────────────────────────
// Regex — compilées une fois au démarrage
// ─────────────────────────────────────────────
var (
	blacklistPattern = regexp.MustCompile(
		`(?i)(cloudflare|bootstrap|jquery|wp-content|jwplayer|awstatic|googleapis|cdn\.|fontawesome|stackpath|popper|min\.js|\.min\.)`,
	)
	jsPattern = regexp.MustCompile(
		`(?i)<script[^>]*src=["']([^"']+\.(?:js|json|config|env))["']`,
	)
	linkPattern = regexp.MustCompile(
		`(?i)<link[^>]*href=["']([^"']+\.(?:js|json))["']`,
	)
	fakeBytes = [][]byte{
		[]byte("404 not found"),
		[]byte("error 404"),
		[]byte("404 error"),
		[]byte("404 - file not found"),
		[]byte("page not found"),
	}
	ignoredCT = []string{
		"image/", "video/", "audio/", "font/",
		"application/octet-stream", "application/zip", "application/pdf",
	}
)

// ─────────────────────────────────────────────
// Constructor
// ─────────────────────────────────────────────
func NewEngine(workers int, timeout time.Duration, extraPaths []string) *Engine {
	// Tous les CPUs disponibles
	runtime.GOMAXPROCS(runtime.NumCPU())

	filePaths := loadPathsFile("paths.txt")
	merged := mergePaths(filePaths, extraPaths)
	if len(merged) == 0 {
		log.Printf("[!] Aucun path chargé — vérifier paths.txt")
	} else {
		log.Printf("[+] %d paths actifs", len(merged))
	}

	return &Engine{
		Client:      NewHTTPClient(timeout),
		Workers:     workers,
		ExtraPaths:  merged,
		ResultsChan: make(chan models.ScrapingResult, resultsChanSize),
		taskChan:    make(chan string, taskChanSize),
		visited:     newShardedSet(),
	}
}

func loadPathsFile(filePath string) []string {
	f, err := os.Open(filePath)
	if err != nil {
		log.Printf("[!] paths.txt introuvable: %v", err)
		return nil
	}
	defer f.Close()
	var paths []string
	sc := bufio.NewScanner(f)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if !strings.HasPrefix(line, "/") {
			line = "/" + line
		}
		paths = append(paths, line)
	}
	log.Printf("[+] paths.txt: %d paths chargés", len(paths))
	return paths
}

func mergePaths(base, extra []string) []string {
	seen := make(map[string]bool, len(base)+len(extra))
	result := make([]string, 0, len(base)+len(extra))
	for _, p := range append(base, extra...) {
		if !seen[p] {
			seen[p] = true
			result = append(result, p)
		}
	}
	return result
}

// ─────────────────────────────────────────────
// ScanDir — compte les URLs et démarre les producteurs
// ─────────────────────────────────────────────
func (e *Engine) ScanDir(ctx context.Context, dirPath string) error {
	ctx, cancel := context.WithCancel(ctx)
	e.cancel = cancel

	entries, err := os.ReadDir(dirPath)
	if err != nil {
		return fmt.Errorf("lecture répertoire: %w", err)
	}

	var txtFiles []string
	for _, f := range entries {
		if !f.IsDir() && strings.HasSuffix(f.Name(), ".txt") {
			fp := filepath.Join(dirPath, f.Name())
			txtFiles = append(txtFiles, fp)
			count, _ := countLines(fp)
			e.TotalURLs.Add(int64(count))
			e.Total.Add(int64(count) * int64(len(e.ExtraPaths)+1))
			log.Printf("[+] %s → %d URLs", f.Name(), count)
		}
	}

	if len(txtFiles) == 0 {
		return fmt.Errorf("aucun fichier .txt dans %s", dirPath)
	}

	log.Printf("[*] %d URLs totales — démarrage producteurs...", e.TotalURLs.Load())

	// Producteurs — N readers parallèles par fichier
	// taskChan de 5M = toujours plein, workers jamais en attente
	go func() {
		defer close(e.taskChan)
		var prodWg sync.WaitGroup
		for _, fp := range txtFiles {
			prodWg.Add(1)
			go func(path string) {
				defer prodWg.Done()
				e.feedFileParallel(ctx, path)
			}(fp)
		}
		prodWg.Wait()
	}()

	return nil
}

func countLines(path string) (int, error) {
	f, err := os.Open(path)
	if err != nil {
		return 0, err
	}
	defer f.Close()
	count := 0
	buf := make([]byte, 128*1024)
	for {
		n, err := f.Read(buf)
		for _, b := range buf[:n] {
			if b == '\n' {
				count++
			}
		}
		if err != nil {
			break
		}
	}
	return count, nil
}

// feedFileParallel — N readers sur des segments du fichier en parallèle
// Sans ça un seul reader ne peut pas alimenter 3000+ workers
func (e *Engine) feedFileParallel(ctx context.Context, filePath string) {
	fi, err := os.Stat(filePath)
	if err != nil || fi.Size() == 0 {
		return
	}

	fileSize := fi.Size()
	segSize := fileSize / int64(numFileReaders)

	var wg sync.WaitGroup
	for i := 0; i < numFileReaders; i++ {
		wg.Add(1)
		start := int64(i) * segSize
		end := start + segSize
		if i == numFileReaders-1 {
			end = fileSize
		}

		go func(start, end int64) {
			defer wg.Done()

			f, err := os.Open(filePath)
			if err != nil {
				return
			}
			defer f.Close()

			// Aligner sur le prochain \n sauf pour le premier segment
			if start > 0 {
				if _, err := f.Seek(start, 0); err != nil {
					return
				}
				tmp := make([]byte, 1)
				for {
					if n, err := f.Read(tmp); n > 0 && tmp[0] == '\n' {
						break
					} else if err != nil {
						return
					}
				}
			}

			sc := bufio.NewReaderSize(f, 4*1024*1024)
			pos := start

			for {
				line, err := sc.ReadString('\n')
				pos += int64(len(line))

				// Stop si on dépasse la fin du segment (sauf dernier)
				if end < fileSize && pos > end {
					break
				}

				line = strings.TrimRight(line, "\r\n ")
				if line != "" && !strings.HasPrefix(line, "#") {
					if !strings.HasPrefix(line, "http") {
						line = "http://" + line
					}
					if strings.Contains(line, "://") {
						select {
						case e.taskChan <- line:
						case <-ctx.Done():
							return
						}
					}
				}

				if err == io.EOF {
					break
				}
				if err != nil {
					break
				}
			}
		}(start, end)
	}
	wg.Wait()
}

// ─────────────────────────────────────────────
// Start — worker pool
// Chaque worker : prend URL → traite racine + tous paths
// Architecture la plus simple = la plus rapide
// ─────────────────────────────────────────────
func (e *Engine) Start(ctx context.Context) {
	if e.cancel == nil {
		ctx, e.cancel = context.WithCancel(ctx)
	}

	paths := e.ExtraPaths

	for i := 0; i < e.Workers; i++ {
		e.wg.Add(1)
		go func() {
			defer e.wg.Done()
			for {
				select {
				case <-ctx.Done():
					return
				case baseURL, ok := <-e.taskChan:
					if !ok {
						return
					}

					// Page racine
					e.processTarget(ctx, baseURL, "/")
					e.Processed.Add(1)

					// Tous les paths
					for _, p := range paths {
						select {
						case <-ctx.Done():
							return
						default:
						}
						e.processTarget(ctx, baseURL, p)
						e.Processed.Add(1)
					}
				}
			}
		}()
	}
}

func (e *Engine) Stop() {
	if e.cancel != nil {
		e.cancel()
	}
	e.wg.Wait()
	close(e.ResultsChan)
}

// ─────────────────────────────────────────────
// processTarget — cœur du scan
// ─────────────────────────────────────────────
func (e *Engine) processTarget(ctx context.Context, baseUrl, path string) {
	fullUrl := buildFullURL(baseUrl, path)
	if fullUrl == "" || isBlacklisted(fullUrl) {
		return
	}

	// ShardedSet — 512x moins de contention que sync.Map
	if !e.visited.setIfAbsent(fullUrl) {
		return
	}

	resp, err := e.doRequest(ctx, fullUrl)
	if err != nil || resp == nil {
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		io.Copy(io.Discard, resp.Body)
		return
	}
	if isIgnoredContentType(resp.Header.Get("Content-Type")) {
		io.Copy(io.Discard, resp.Body)
		return
	}

	// Buffer poolé — zéro allocation
	bufPtr := bufPool.Get().(*[]byte)
	defer bufPool.Put(bufPtr)
	buf := *bufPtr

	n, err := io.ReadFull(resp.Body, buf)
	if err != nil && err != io.ErrUnexpectedEOF && err != io.EOF {
		return
	}
	body := buf[:n]

	if isFakeContentBytes(body) {
		return
	}

	content := string(body)

	// Détection secrets
	for _, hit := range detector.DetectAll(content) {
		hit.Url = fullUrl
		hit.Path = path
		hit.DiscoveredAt = time.Now()
		hit.Status = "unchecked"
		e.TotalHits.Add(1)
		select {
		case e.ResultsChan <- hit:
		default:
		}
	}

	// Crawl JS/links depuis la racine uniquement
	if path == "" || path == "/" {
		e.extractResources(ctx, baseUrl, content)
	}
}

func (e *Engine) doRequest(ctx context.Context, fullUrl string) (*http.Response, error) {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, fullUrl, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
	req.Header.Set("Accept", "*/*")
	req.Header.Set("Accept-Encoding", "gzip, deflate")
	return e.Client.Do(req)
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

func buildFullURL(baseUrl, path string) string {
	switch {
	case path == "" || path == "/":
		return baseUrl
	case strings.HasPrefix(path, "JS:"):
		return strings.TrimPrefix(path, "JS:")
	case strings.HasPrefix(path, "LINK:"):
		return strings.TrimPrefix(path, "LINK:")
	default:
		if strings.HasPrefix(path, "/") {
			base, err := url.Parse(baseUrl)
			if err != nil {
				return ""
			}
			return base.Scheme + "://" + base.Host + path
		}
		resolved, err := safeResolveURL(baseUrl, path)
		if err != nil {
			return ""
		}
		return resolved
	}
}

func safeResolveURL(baseURL, rawPath string) (string, error) {
	base, err := url.Parse(baseURL)
	if err != nil {
		return "", err
	}
	ref, err := url.Parse(rawPath)
	if err != nil {
		return "", err
	}
	resolved := base.ResolveReference(ref)
	if resolved.Host != base.Host {
		return "", fmt.Errorf("host mismatch")
	}
	resolved.Path = filepath.Clean(resolved.Path)
	return resolved.String(), nil
}

func (e *Engine) extractResources(ctx context.Context, baseUrl, html string) {
	seen := make(map[string]bool)
	add := func(rawURL, prefix string) {
		if isBlacklisted(rawURL) {
			return
		}
		full, err := safeResolveURL(baseUrl, rawURL)
		if err != nil || seen[full] {
			return
		}
		seen[full] = true
		key := prefix + full
		if e.visited.setIfAbsent(key) {
			go e.processTarget(ctx, baseUrl, prefix+full)
		}
	}
	for _, m := range jsPattern.FindAllStringSubmatch(html, -1) {
		if len(m) > 1 {
			add(m[1], "JS:")
		}
	}
	for _, m := range linkPattern.FindAllStringSubmatch(html, -1) {
		if len(m) > 1 {
			add(m[1], "LINK:")
		}
	}
}

func extractHost(rawURL string) string {
	u, err := url.Parse(rawURL)
	if err != nil {
		return rawURL
	}
	return u.Host
}

func isBlacklisted(u string) bool { return blacklistPattern.MatchString(u) }

func isIgnoredContentType(ct string) bool {
	ct = strings.ToLower(ct)
	for _, ig := range ignoredCT {
		if strings.Contains(ct, ig) {
			return true
		}
	}
	return false
}

func isFakeContentBytes(body []byte) bool {
	if len(body) > 5000 {
		return false
	}
	lower := bytes.ToLower(body)
	for _, p := range fakeBytes {
		if bytes.Contains(lower, p) {
			return true
		}
	}
	return false
}
