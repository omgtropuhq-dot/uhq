package scanner

import (
	"crypto/tls"
	"net"
	"net/http"
	"time"
)

func NewHTTPClient(timeout time.Duration) *http.Client {
	dialer := &net.Dialer{
		Timeout:   1500 * time.Millisecond,
		KeepAlive: 30 * time.Second,
		DualStack: true,
	}

	transport := &http.Transport{
		Proxy:       http.ProxyFromEnvironment,
		DialContext: dialer.DialContext,

		// Pool de connexions massif pour 1Gbps
		MaxIdleConns:        100000,
		MaxIdleConnsPerHost: 512,
		MaxConnsPerHost:     0, // illimité

		IdleConnTimeout:       90 * time.Second,
		TLSHandshakeTimeout:   2 * time.Second,
		ExpectContinueTimeout: 500 * time.Millisecond,
		ResponseHeaderTimeout: 3 * time.Second,

		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
			MinVersion:         tls.VersionTLS10,
			// Session cache — évite le TLS handshake complet à chaque connexion
			ClientSessionCache: tls.NewLRUClientSessionCache(100000),
		},

		DisableCompression: false, // gzip activé = moins de bande passante
		DisableKeepAlives:  false, // keep-alive = réutilise les TCP connections
		ForceAttemptHTTP2:  false, // HTTP/1.1 uniquement — plus simple et plus rapide

		WriteBufferSize: 4 * 1024,
		ReadBufferSize: 128 * 1024,  // 128KB au lieu de 32KB,
	}

	return &http.Client{
		Transport: transport,
		Timeout:   timeout,
		CheckRedirect: func(req *http.Request, via []*http.Request) error {
			if len(via) >= 2 {
				return http.ErrUseLastResponse
			}
			return nil
		},
	}
}
