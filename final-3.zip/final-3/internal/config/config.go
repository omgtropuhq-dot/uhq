package config

import (
	"encoding/json"
	"os"
)

type Config struct {
	InputDir   string   `json:"input_dir"`
	Workers    int      `json:"workers"`
	Timeout    int      `json:"timeout"`
	Language   string   `json:"language"`
	Validate   bool     `json:"validate"`
	Telegram   Telegram `json:"telegram"`
	ExtraPaths []string `json:"extra_paths"`
}

type Telegram struct {
	Token            string `json:"token"`
	ValidChannelID   string `json:"valid_channel_id"`
	InvalidChannelID string `json:"invalid_channel_id"`
	StatsChannelID   string `json:"stats_channel_id"`
	Enabled          bool   `json:"enabled"`
}

func LoadConfig(path string) (*Config, error) {
	file, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var cfg Config
	if err := json.NewDecoder(file).Decode(&cfg); err != nil {
		return nil, err
	}

	if cfg.Workers == 0 {
		cfg.Workers = 500
	}
	if cfg.Timeout == 0 {
		cfg.Timeout = 8
	}
	if cfg.Language == "" {
		cfg.Language = "en"
	}
	if cfg.InputDir == "" {
		cfg.InputDir = "Check"
	}

	return &cfg, nil
}
