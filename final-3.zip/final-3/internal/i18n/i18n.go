package i18n

import "fmt"

type Language string

const (
	EN Language = "en"
	FR Language = "fr"
)

var CurrentLang Language = EN

var messages = map[Language]map[string]string{
	EN: {
		"app_name":          "Glitch Cracker Go",
		"startup":           "Starting system...",
		"loading_modules":   "Loading advanced modules...",
		"ready":             "System ready!",
		"scan_config":       "SCAN CONFIGURATION",
		"mode":              "Mode",
		"paths":             "Paths",
		"js":                "JavaScript",
		"git":               "Git Dump",
		"rce":               "RCE",
		"status_enabled":    "ENABLED",
		"status_disabled":   "DISABLED",
		"error_no_option":   "At least one option must be enabled (Paths, JS, GIT, or RCE)",
		"target_file":       "Target File",
		"file_not_found":    "File not found: %s",
		"processing":        "Processing: %s",
		"progress":          "Progress: %d/%d",
		"scan_finished":     "Scan finished! Hits found: %d",
		"hit_detected":      "[NEW HIT DETECTED] %s",
		"hit_duplicate":     "[DUPLICATE HIT IGNORED] %s",
		"error_critical":    "CRITICAL ERROR: %s",
		"stopping":          "STOPPING IN PROGRESS",
		"sending_results":   "Sending results...",
		"done":              "DONE",
		"checking_path":     "Checking path: %s",
		"validating_key":    "Validating key for %s...",
		"key_valid":         "[KEY VALID] %s",
		"key_invalid":       "[KEY INVALID] %s",
	},
	FR: {
		"app_name":          "Glitch Cracker Go",
		"startup":           "Démarrage du système...",
		"loading_modules":   "Chargement des modules avancés...",
		"ready":             "Système prêt !",
		"scan_config":       "CONFIGURATION DU SCAN",
		"mode":              "Mode",
		"paths":             "Chemins",
		"js":                "JavaScript",
		"git":               "Git Dump",
		"rce":               "RCE",
		"status_enabled":    "ACTIVÉ",
		"status_disabled":   "DÉSACTIVÉ",
		"error_no_option":   "Au moins une option doit être activée (Paths, JS, GIT ou RCE)",
		"target_file":       "Fichier cible",
		"file_not_found":    "Fichier non trouvé : %s",
		"processing":        "Traitement : %s",
		"progress":          "Progression : %d/%d",
		"scan_finished":     "Scan terminé ! Hits trouvés : %d",
		"hit_detected":      "[NOUVEAU HIT DÉTECTÉ] %s",
		"hit_duplicate":     "[HIT EN DOUBLON IGNORÉ] %s",
		"error_critical":    "ERREUR CRITIQUE : %s",
		"stopping":          "ARRÊT EN COURS",
		"sending_results":   "Envoi des résultats...",
		"done":              "TERMINÉ",
		"checking_path":     "Vérification du chemin : %s",
		"validating_key":    "Validation de la clé pour %s...",
		"key_valid":         "[CLÉ VALIDE] %s",
		"key_invalid":       "[CLÉ INVALIDE] %s",
	},
}

func T(key string, args ...interface{}) string {
	msg, ok := messages[CurrentLang][key]
	if !ok {
		return key
	}
	if len(args) > 0 {
		return fmt.Sprintf(msg, args...)
	}
	return msg
}

func SetLanguage(lang string) {
	if lang == "fr" {
		CurrentLang = FR
	} else {
		CurrentLang = EN
	}
}