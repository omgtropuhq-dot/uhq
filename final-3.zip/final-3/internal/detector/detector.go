package detector

import (
	"encoding/base64"
	"glitchcracker/pkg/models"
	"regexp"
	"strings"
	"time"
)

var (
	twilioSidRegex     = regexp.MustCompile(`(?i)(?:TWILIO_ACCOUNT_SID|accountSid|account_sid)\s*[:=]\s*['"]?(AC[0-9a-fA-F]{32})['"]?`)
	twilioTokenRegex   = regexp.MustCompile(`(?i)(?:TWILIO_AUTH_TOKEN|authToken|auth_token)\s*[:=]\s*['"]([0-9a-fA-F]{32})['"]`)
	twilioEncodedRegex = regexp.MustCompile(`QU[MN][A-Za-z0-9]{87}==`)

	sendgridPatterns = []*regexp.Regexp{
		regexp.MustCompile(`SG\.[A-Za-z0-9_-]{22}\.[A-Za-z0-9_-]{43}`),
		regexp.MustCompile(`(?i)(?:SENDGRID_API_KEY|sendgrid[_\-]?key)\s*[:=]\s*['"]?(SG\.[A-Za-z0-9_-]{20,80})['"]?`),
	}

	stripeSecretRegex = regexp.MustCompile(`sk_live_[a-zA-Z0-9]{24,99}`)
	brevoRegex        = regexp.MustCompile(`xkeysib-[a-f0-9]{64}-[a-zA-Z0-9]{16}`)
	mandrillRegex     = regexp.MustCompile(`(?i)(?:mandrill[_\-]?(?:api[_\-]?)?key|MANDRILL_KEY)\s*[:=]\s*["'](md-[0-9a-zA-Z]{22})["']`)
	mailersendRegex   = regexp.MustCompile(`\bmlsn\.[0-9a-zA-Z]{70}\b`)
	xsmtpRegex        = regexp.MustCompile(`\bxsmtpsib-[a-fA-F0-9]{64}-[A-Za-z0-9]{16}\b`)
	oldMailgunRegex   = regexp.MustCompile(`(?i)(?:mailgun[_\-]?(?:api[_\-]?)?key|MAILGUN_KEY)\s*[:=]\s*['"]?(key-[a-f0-9]{32})['"]?`)
	newMailgunRegex   = regexp.MustCompile(`(?i)(?:mailgun[_\-]?(?:api[_\-]?)?(?:key|secret)|MAILGUN)\s*[:=]\s*["']?([a-f0-9]{32}-[0-9a-f]{8}-[a-f0-9]{8})["']?`)
	postmarkRegex     = regexp.MustCompile(`(?i)(?:POSTMARK_API_TOKEN|postmark[_\-]?(?:api[_\-]?)?(?:key|token))\s*[:=]\s*['"]([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})['"]`)
	sparkpostRegex    = regexp.MustCompile(`(?i)(?:SPARKPOST_API_KEY|sparkpost[_\-]?key)\s*[:=]\s*['"]([a-f0-9]{40})['"]`)
	mailjetPublicRegex  = regexp.MustCompile(`(?i)(?:MJ_APIKEY_PUBLIC|mailjet[_\-]?public)\s*[:=]\s*['"]([a-f0-9]{32})['"]`)
	mailjetPrivateRegex = regexp.MustCompile(`(?i)(?:MJ_APIKEY_PRIVATE|mailjet[_\-]?(?:private|secret))\s*[:=]\s*['"]([a-f0-9]{32})['"]`)

	smtpHostPatterns = []*regexp.Regexp{
		regexp.MustCompile(`(?i)(?:MAIL_HOST|SMTP_HOST|MAIL_SERVER|smtp_server)\s*[:=]\s*['"]([A-Za-z0-9.-]+\.[A-Za-z]{2,})['"]`),
	}
	smtpUserPatterns = []*regexp.Regexp{
		regexp.MustCompile(`(?i)(?:MAIL_USERNAME|SMTP_USER|MAIL_USER|smtp_username)\s*[:=]\s*['"]([^"'\s@]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,})['"]`),
	}
	smtpPassPatterns = []*regexp.Regexp{
		regexp.MustCompile(`(?i)(?:MAIL_PASSWORD|SMTP_PASS|MAIL_PASS|smtp_password)\s*[:=]\s*['"]([^"'\s]{6,64})['"]`),
	}
)

func isInvalidValue(val string) bool {
	v := strings.ToLower(strings.TrimSpace(val))
	if v == "" {
		return true
	}
	invalids := []string{
		"null", "none", "false", "true", "undefined", "empty",
		"your_password", "password", "changeme", "secret", "placeholder",
		"xxx", "test", "example", "sample", "default", "replace",
		"your-", "your_", "<your", "${", "{{", "xxxxxxxx",
	}
	for _, inv := range invalids {
		if v == inv || strings.HasPrefix(v, inv) {
			return true
		}
	}
	if strings.HasPrefix(v, "<") || strings.HasPrefix(v, "{{") || strings.HasPrefix(v, "${") {
		return true
	}
	return false
}

func DetectAll(content string) []models.ScrapingResult {
	var results []models.ScrapingResult
	uniqueMap := make(map[string]bool)

	addResult := func(res models.ScrapingResult) {
		fp := strings.TrimSpace(res.AKIA + res.SecretKey + res.SendGridApiKey + res.StripeSecretKey +
			res.TwilioAccountSid + res.SmtpPass + res.BrevoApiKey +
			res.MandrillApiKey + res.MailersendApiKey + res.XsmtpsibApiKey +
			res.NewMailgunApiKey + res.MailgunApiKey + res.PostmarkApiKey + res.SparkpostApiKey)
		if fp == "" && len(res.Services) > 0 {
			fp = res.Services[0] + res.Url
		}
		if fp != "" && !uniqueMap[fp] {
			uniqueMap[fp] = true
			results = append(results, res)
		}
	}

	for _, awsHit := range DetectAWS(content) {
		if !isInvalidValue(awsHit.AKIA) && !isInvalidValue(awsHit.SecretKey) {
			addResult(awsHit)
		}
	}

	if sids := twilioSidRegex.FindAllStringSubmatch(content, -1); len(sids) > 0 {
		tokens := twilioTokenRegex.FindAllStringSubmatch(content, -1)
		for _, sid := range sids {
			if isInvalidValue(sid[1]) { continue }
			res := models.ScrapingResult{TwilioAccountSid: sid[1], Services: []string{"Twilio"}, DiscoveredAt: time.Now()}
			if len(tokens) > 0 && !isInvalidValue(tokens[0][1]) {
				res.TwilioAuthToken = tokens[0][1]
			}
			addResult(res)
		}
	}
	if match := twilioEncodedRegex.FindString(content); match != "" {
		decoded, err := base64.StdEncoding.DecodeString(match)
		if err == nil {
			parts := strings.Split(string(decoded), ":")
			if len(parts) == 2 && strings.HasPrefix(parts[0], "AC") {
				addResult(models.ScrapingResult{TwilioAccountSid: parts[0], TwilioAuthToken: parts[1], Services: []string{"Twilio-Encoded"}, DiscoveredAt: time.Now()})
			}
		}
	}

	for _, re := range sendgridPatterns {
		for _, m := range re.FindAllStringSubmatch(content, -1) {
			val := m[0]
			if len(m) > 1 && m[1] != "" { val = m[1] }
			if !isInvalidValue(val) {
				addResult(models.ScrapingResult{SendGridApiKey: val, Services: []string{"SendGrid"}, DiscoveredAt: time.Now()})
			}
		}
	}

	var foundHosts, foundUsers, foundPasses []string
	for _, re := range smtpHostPatterns {
		for _, m := range re.FindAllStringSubmatch(content, -1) {
			if len(m) > 1 && !isInvalidValue(m[1]) { foundHosts = append(foundHosts, m[1]) }
		}
	}
	for _, re := range smtpUserPatterns {
		for _, m := range re.FindAllStringSubmatch(content, -1) {
			if len(m) > 1 && !isInvalidValue(m[1]) { foundUsers = append(foundUsers, m[1]) }
		}
	}
	for _, re := range smtpPassPatterns {
		for _, m := range re.FindAllStringSubmatch(content, -1) {
			if len(m) > 1 && !isInvalidValue(m[1]) { foundPasses = append(foundPasses, m[1]) }
		}
	}
	if len(foundHosts) > 0 && len(foundPasses) > 0 {
		res := models.ScrapingResult{SmtpHost: foundHosts[0], SmtpPass: foundPasses[0], Services: []string{"SMTP"}, DiscoveredAt: time.Now()}
		if len(foundUsers) > 0 { res.SmtpUser = foundUsers[0] }
		addResult(res)
	}

	for _, m := range stripeSecretRegex.FindAllString(content, -1) {
		if !isInvalidValue(m) { addResult(models.ScrapingResult{StripeSecretKey: m, Services: []string{"Stripe"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range brevoRegex.FindAllString(content, -1) {
		if !isInvalidValue(m) { addResult(models.ScrapingResult{BrevoApiKey: m, Services: []string{"Brevo"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range mandrillRegex.FindAllStringSubmatch(content, -1) {
		if len(m) > 1 && !isInvalidValue(m[1]) { addResult(models.ScrapingResult{MandrillApiKey: m[1], Services: []string{"Mandrill"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range mailersendRegex.FindAllString(content, -1) {
		if !isInvalidValue(m) { addResult(models.ScrapingResult{MailersendApiKey: m, Services: []string{"Mailersend"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range xsmtpRegex.FindAllString(content, -1) {
		if !isInvalidValue(m) { addResult(models.ScrapingResult{XsmtpsibApiKey: m, Services: []string{"XSMTP"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range oldMailgunRegex.FindAllStringSubmatch(content, -1) {
		if len(m) > 1 && !isInvalidValue(m[1]) { addResult(models.ScrapingResult{MailgunApiKey: m[1], Services: []string{"Mailgun"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range newMailgunRegex.FindAllStringSubmatch(content, -1) {
		if len(m) > 1 && !isInvalidValue(m[1]) { addResult(models.ScrapingResult{NewMailgunApiKey: m[1], Services: []string{"Mailgun-New"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range postmarkRegex.FindAllStringSubmatch(content, -1) {
		if len(m) > 1 && !isInvalidValue(m[1]) { addResult(models.ScrapingResult{PostmarkApiKey: m[1], Services: []string{"Postmark"}, DiscoveredAt: time.Now()}) }
	}
	for _, m := range sparkpostRegex.FindAllStringSubmatch(content, -1) {
		if len(m) > 1 && !isInvalidValue(m[1]) { addResult(models.ScrapingResult{SparkpostApiKey: m[1], Services: []string{"SparkPost"}, DiscoveredAt: time.Now()}) }
	}

	pubMatches := mailjetPublicRegex.FindAllStringSubmatch(content, -1)
	privMatches := mailjetPrivateRegex.FindAllStringSubmatch(content, -1)
	if len(pubMatches) > 0 && len(privMatches) > 0 {
		pub, priv := pubMatches[0][1], privMatches[0][1]
		if !isInvalidValue(pub) && !isInvalidValue(priv) {
			res := models.ScrapingResult{Services: []string{"Mailjet"}, DiscoveredAt: time.Now(), Credentials: map[string]interface{}{"PublicKey": pub, "PrivateKey": priv}}
			addResult(res)
		}
	}

	return results
}
