package detector

import (
	"glitchcracker/pkg/models"
	"regexp"
	"strings"
)

var (
	// AKIA/ASIA/AROA/AIDA + 16 chars — format AWS standard
	awsKeyRegex = regexp.MustCompile(`\b(AKIA|ASIA|AROA|AIDA)([A-Z0-9]{16})\b`)

	// Secret key — guillemets obligatoires pour éviter faux positifs JS
	awsSecretRegex = regexp.MustCompile(`(?i)(?:aws_secret_access_key|secret_access_key|aws_secret|SecretAccessKey|aws_secret_key)\s*[:=]\s*["']([A-Za-z0-9/+=]{40})["']`)

	// Session token — 100+ chars, contexte strict
	awsSessionRegex = regexp.MustCompile(`(?i)(?:aws_session_token|session_token|SessionToken)\s*[:=]\s*["']([A-Za-z0-9/+=]{100,})["']`)
)

func DetectAWS(content string) []models.ScrapingResult {
	var results []models.ScrapingResult

	keys := awsKeyRegex.FindAllString(content, -1)
	if len(keys) == 0 {
		return nil
	}

	var secrets []string
	for _, m := range awsSecretRegex.FindAllStringSubmatch(content, -1) {
		if !isInvalidValue(m[1]) {
			secrets = append(secrets, m[1])
		}
	}

	var sessions []string
	for _, m := range awsSessionRegex.FindAllStringSubmatch(content, -1) {
		if !isInvalidValue(m[1]) {
			sessions = append(sessions, m[1])
		}
	}

	for i, key := range keys {
		if isInvalidValue(key) {
			continue
		}
		res := models.ScrapingResult{AKIA: key, Services: []string{"AWS"}}
		if i < len(secrets) {
			res.SecretKey = secrets[i]
		}
		if strings.HasPrefix(key, "ASIA") && len(sessions) > 0 {
			if res.Credentials == nil {
				res.Credentials = make(map[string]interface{})
			}
			res.Credentials["SessionToken"] = sessions[0]
		}
		results = append(results, res)
	}
	return results
}
